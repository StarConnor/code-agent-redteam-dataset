<?php

global $w2dc_listing_page_widget_params;
$w2dc_listing_page_widget_params = array(
		array(
				'type' => 'directory',
				'param_name' => 'directory',
				'heading' => __("Select directory", "W2DC"),
		),
);

?>